const footerTemplate = document.createElement('template');

footerTemplate.innerHTML = `
<style>
    @import url("https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css");
    footer {
    height: 60px;
    padding: 0 10px;
    list-style: none;
      display: flex;
      flex-shrink: 0;
      justify-content: space-between;
      align-items: center;
      background-color: #dfdfe2;
    }
    ul {
      padding: 0;
    }
    
    ul li {
      list-style: none;
      display: inline;
    }
    
    a {
      margin: 0 15px;
      color: inherit;
      text-decoration: none;
    }
    
    a:hover {
      padding-bottom: 5px;
      box-shadow: inset 0 -2px 0 0 #333;
    }
    
    .social-row {
      font-size: 20px;
    }
    
    .social-row li a {
      margin: 0 15px;
    }
  </style>
  <footer>
  <div class="container">
  <div class="row">
    <div class="col-md-6 text-center text-md-start">
      <p>Copyright © YourStartup. All rights reserved.</p>
    </div>
    <div class="col-md-6 text-center text-md-end mb-4">
      <a href="#" class="m-2">
        <i class="fab fa-twitter fa-lg text-white"
          aria-hidden="true"></i>
      </a>
      <a href="#" class="m-2">
        <i class="fab fa-facebook fa-lg text-white"
          aria-hidden="true"></i>
      </a>
      <a href="#" class="m-2">
        <i class="fab fa-instagram fa-lg text-white"
          aria-hidden="true"></i>
      </a>
      <a href="#" class="m-2">
        <i class="fab fa-pinterest fa-lg text-white"
          aria-hidden="true"></i>
      </a>
      <a href="#" class="m-2">
        <i class="fab fa-google fa-lg text-white"
          aria-hidden="true"></i>
      </a>
    </div>
  </div>
</div>
  </footer>
`;

class Footer extends HTMLElement {
  constructor() {
    super();
  }

  connectedCallback() {
    // Query the main DOM for FA
    const fontAwesome = document.querySelector('link[href*="font-awesome"]');
    const shadowRoot = this.attachShadow({ mode: 'closed' });

    // Conditionally load FA to the component
    if (fontAwesome) {
      shadowRoot.appendChild(fontAwesome.cloneNode());
    }

    shadowRoot.appendChild(footerTemplate.content);
  }
}

customElements.define('footer-component', Footer);