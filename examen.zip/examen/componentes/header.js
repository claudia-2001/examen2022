const headerTemplate = document.createElement('template');

headerTemplate.innerHTML = `
  <style>
    nav {
      height: 40px;
      display: flex;
      align-items: center;
      justify-content: center;
      background-color:  #0a0a23;
    }
    ul {
      padding: 0;
    }
    
    ul li {
      list-style: none;
      display: inline;
    }
    
    a {
      font-weight: 700;
      margin: 0 25px;
      color: #fff;
      text-decoration: none;
    }
    
    a:hover {
      padding-bottom: 5px;
      box-shadow: inset 0 -2px 0 0 #fff;
    }
  </style>
  <header>
  <nav class="navbar navbar-dark bg-dark navbar-expand-md ">
  <div class="container">
	<div class="col-2 text-left pl-md-0">
	  <a href="#">
		<img src=" https://dummyimage.com/102x30/007bff/ffffff?text=logo"
		  height="30" alt="image">
	  </a>
	</div>
	<button class="navbar-toggler" type="button" data-toggle="collapse"
	  data-target=".navbar-collapse-3" aria-controls="navbarNav6"
	  aria-expanded="false" aria-label="Toggle navigation">
	  <span class="navbar-toggler-icon"></span>
	</button>
	<div
	  class="collapse navbar-collapse justify-content-center col-md-8 navbar-collapse-3">
	  <ul class="navbar-nav justify-content-center">
		<li class="nav-item active">
		  <a class="nav-link" href="home.html">Home</a>
		<li class="nav-item">
		  <a class="nav-link" href="acercadenosotros.html">Acerca de nosotros</a>
		</li>
		<li class="nav-item">
		  <a class="nav-link" href="nuestrosservicios.html">Nuestros servicios</a>
		</li>
		<li class="nav-item">
		  <a class="nav-link" href="contacto.html">Contacto</a>
		</li>
	  </ul>
	</div>
	<div
	  class="collapse navbar-collapse justify-content-end col-md-2 navbar-collapse-3">
	  <ul class="navbar-nav">
		<li class="nav-item">
		  <a class="nav-link" href="#">Registrar →</a>
		</li>
	  </ul>
	</div>
  </div>
</nav>
  </header>
`;

class Header extends HTMLElement {
  constructor() {
    super();
  }

  connectedCallback() {
    const shadowRoot = this.attachShadow({ mode: 'closed' });

    shadowRoot.appendChild(headerTemplate.content);
  }
}

customElements.define('header-component', Header);